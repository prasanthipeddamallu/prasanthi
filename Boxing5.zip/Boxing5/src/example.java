
public class example {

	public static void main(String[] args) {
		 int a=250;  
	        Integer a2=new Integer(a);  
	  
	        Integer a3=50;
	          
	        System.out.println(a2+" "+a3);  
	 }   
	  

	}


