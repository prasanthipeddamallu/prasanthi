
public class example1 {

	public static void main(String[] args) {
		
		Integer i=new Integer(500);  
        int a=i;  
          
        System.out.println(a);  
 }   
 
      

	}

