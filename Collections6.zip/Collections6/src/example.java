

import java.util.ArrayList;
import java.util.Collections;


	public class example { 
		public static void main(String[] args) { 
		ArrayList<String> myList = new ArrayList<String>(); 
		myList.add("AWS"); 
		myList.add("Java"); 
		myList.add("Python"); 
		myList .add("Blockchain"); 
		System.out.println("Before Reversing"); 
		System.out.println(myList.toString()); 
		Collections.reverse(myList); 
		System.out.println("After Reversing"); 
		System.out.println(myList); 
		} 

}
