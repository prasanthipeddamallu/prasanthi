
public class example {

	static void varargs(String... values){  
		System.out.println("varargs method invoked ");  
		  for(String s:values){  
		   System.out.println(s);  
		  }  
		 }  
		  
		 public static void main(String args[]){  
		  
		 varargs();  
		 varargs("hello");  
		 varargs("my","name","is","varargs");  
		 }   
		}  	
		 


