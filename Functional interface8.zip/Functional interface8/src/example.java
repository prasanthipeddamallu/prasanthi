

	interface HelloJava{  
	    void say(String msg);  
	}  
	public class example{  
	    public void say(String msg){  
	        System.out.println(msg);  
	    }  
	    public static void main(String[] args) {  
	       example java= new example();  
	        java.say("Hello World");  
	    }  
	}  

