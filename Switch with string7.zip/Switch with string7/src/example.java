
public class example {
	 public static void main(String[] args) {  
	        String game = "Football";  
	        switch(game){  
	        case "Hockey":  
	            System.out.println("Let's play Hockey");  
	            break;  
	        case "Cricket":  
	            System.out.println("Let's play Football");  
	            break;  
	        case "Football":  
	            System.out.println("Let's play Football");  
	        }  
	    }  
	}  

