
public class example7 {

}
