
public class example {
	
	    public static void main(String[] args) {  
	          
	        int a = 10_00000;  
	        System.out.println("a = "+a);  
	        
	        float b = 10.5_000f;  
	        System.out.println("b = "+b);  
	          
	        int c = 0B10_10;  
	        System.out.println("c = "+c);  
	       
	        int d = 0x1_1;  
	        System.out.println("d = "+d);  
	        
	        int e = 01_1;  
	        System.out.println("e = "+e);  
	    }  
	}  

