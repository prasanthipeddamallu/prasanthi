import static java.lang.System.*; 
public class example {
public static void main(String args[]){  
	     
	   out.println("Hello");  
	   out.println("World");  
	  
	 }   
	}    



